# !/usr/bin/python

import pyspark
from pyspark.sql import SparkSession
import traceback

class spark_config:
    
    def __init__(self):
        print "Init Spark Config Class"
        
    def __init_spark(self,log):
        try:
            return SparkSession.builder.appName("FITS Surrogate").getOrCreate()
        except Exception as e:
            log.error("spark_config,__init_spark",traceback.print_exc())    