# !/usr/bin/python

import pyspark
from pyspark.sql import SparkSession
import traceback

class file_loader:
    def __init__(self):
        pass
    
    def __load_files(self,spark,format_,flag,path,log):
        try:
            return spark.read.format(format_).option("header",flag).load(path)
        except Exception as e:
            log.error("spark_config,__load_files, exception",traceback.print_exc())